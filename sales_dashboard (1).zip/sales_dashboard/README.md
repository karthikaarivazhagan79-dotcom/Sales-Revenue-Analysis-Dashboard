# 📊 SalesScope — Sales & Revenue Analysis Dashboard

A full-stack web application for uploading, storing, and visualizing sales data.
Built with **Flask**, **SQLite**, **Chart.js**, and a polished dark/light UI.

---

## 🗂 Project Structure

```
sales_dashboard/
├── app.py                  # Flask app, routes, API endpoints
├── requirements.txt        # Python dependencies
├── README.md               # This file
├── instance/
│   └── sales_dashboard.db  # SQLite database (auto-created)
├── static/
│   ├── css/
│   │   └── style.css       # Full stylesheet (dark + light theme)
│   ├── js/
│   │   ├── theme.js        # Dark/light mode toggle
│   │   └── dashboard.js    # Charts, KPIs, filters
│   ├── uploads/            # Uploaded files stored here
│   └── sample_data.csv     # Sample dataset for testing
└── templates/
    ├── base.html           # Base layout with sidebar
    ├── dashboard.html      # Main analytics dashboard
    ├── upload.html         # File upload page
    ├── login.html          # Login page
    └── signup.html         # Signup page
```

---

## ⚡ Quick Start (5 minutes)

### 1. Prerequisites
- Python 3.8 or higher
- pip

### 2. Set up the environment

```bash
# Navigate into the project folder
cd sales_dashboard

# (Recommended) Create a virtual environment
python -m venv venv

# Activate it
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the app

```bash
python app.py
```

### 5. Open in browser

```
http://127.0.0.1:5000
```

---

## 🔐 Login

A demo account is created automatically on first launch:

| Field    | Value      |
|----------|------------|
| Username | `demo`     |
| Password | `demo1234` |

The app also seeds **500 demo sales records** automatically so the dashboard is
populated on first load. You can clear this data from the dashboard and upload
your own.

---

## 📁 Uploading Your Own Data

Click **Upload Data** in the sidebar and upload a CSV or Excel file.

### Minimum required columns:
| Column     | Description           |
|------------|-----------------------|
| `date`     | Sale date (any format)|
| `product`  | Product name          |
| `category` | Product category      |

### Optional columns (auto-calculated if missing):
| Column          | Description            |
|-----------------|------------------------|
| `total_revenue` | Total sale amount      |
| `quantity`      | Units sold             |
| `unit_price`    | Price per unit         |
| `region`        | Geographic region      |
| `order_id`      | Unique order reference |
| `customer`      | Customer name          |

Column names are flexible — the app recognizes common variations like
`sale_date`, `item_name`, `qty`, `total_sales`, etc.

---

## 📊 Features

| Feature                        | Status |
|-------------------------------|--------|
| CSV & Excel upload             | ✅     |
| SQLite data storage            | ✅     |
| Total Revenue KPI              | ✅     |
| Total Orders KPI               | ✅     |
| Units Sold KPI                 | ✅     |
| Average Order Value KPI        | ✅     |
| Revenue trend line chart       | ✅     |
| Top products bar chart         | ✅     |
| Category distribution donut    | ✅     |
| Region polar area chart        | ✅     |
| Date range filter              | ✅     |
| Category filter                | ✅     |
| Product filter                 | ✅     |
| Recent transactions table      | ✅     |
| Export PDF report              | ✅     |
| User authentication            | ✅     |
| Dark / Light mode toggle       | ✅     |
| Responsive design              | ✅     |

---

## 🛠 Tech Stack

- **Backend**: Python 3, Flask, Flask-SQLAlchemy, Flask-Login
- **Database**: SQLite (via SQLAlchemy ORM)
- **Frontend**: Vanilla JS, Chart.js 4, CSS custom properties
- **Fonts**: Space Mono + DM Sans (Google Fonts)
- **PDF Export**: ReportLab

---

## 🔧 Configuration

Edit `app.py` to change:

```python
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change in production!
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sales_dashboard.db'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max
```

---

## 🚀 Production Notes

For a production deployment:

1. Change `SECRET_KEY` to a random secure value
2. Set `debug=False` in `app.run()`
3. Use a proper WSGI server (Gunicorn, uWSGI)
4. Consider PostgreSQL instead of SQLite for concurrent users

```bash
pip install gunicorn
gunicorn -w 4 app:app
```

---

## 📦 Sample Dataset

A `static/sample_data.csv` file is included with 120 records across:
- **5 categories**: Electronics, Clothing, Books, Home & Garden, Sports
- **25 products** with realistic prices
- **5 regions**: North, South, East, West, Central
- **Date range**: Jan 2023 – Dec 2023
