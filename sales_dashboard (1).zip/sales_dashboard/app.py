"""
Sales & Revenue Analysis Dashboard
===================================
Flask application using stdlib sqlite3 only (no ORM required).
Compatible with: Flask, pandas, openpyxl, reportlab, Werkzeug
"""

import os
import json
import sqlite3
import hashlib
import datetime
import random
import io

import pandas as pd
from flask import (
    Flask, render_template, request, redirect, url_for,
    jsonify, flash, send_file, session, g
)
from werkzeug.utils import secure_filename

# ─── App Configuration ────────────────────────────────────────────────────────

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key-change-in-production'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB
ALLOWED_EXTENSIONS = {'csv', 'xlsx', 'xls'}
DB_PATH = os.path.join(os.path.dirname(__file__), 'instance', 'sales_dashboard.db')

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

# ─── Database Helpers ─────────────────────────────────────────────────────────

def get_db():
    """Return a per-request SQLite connection stored on Flask's g object."""
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db:
        db.close()

def init_db():
    """Create tables and indexes if they don't already exist."""
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT UNIQUE NOT NULL,
            email         TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at    TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS sales (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id      TEXT,
            date          TEXT NOT NULL,
            product       TEXT NOT NULL,
            category      TEXT NOT NULL,
            quantity      INTEGER NOT NULL DEFAULT 1,
            unit_price    REAL    NOT NULL DEFAULT 0,
            total_revenue REAL    NOT NULL DEFAULT 0,
            region        TEXT DEFAULT 'Unknown',
            customer      TEXT DEFAULT '',
            upload_batch  TEXT,
            uploaded_at   TEXT DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_sales_date     ON sales(date);
        CREATE INDEX IF NOT EXISTS idx_sales_category ON sales(category);
        CREATE INDEX IF NOT EXISTS idx_sales_product  ON sales(product);
    """)
    db.commit()
    db.close()

# ─── Auth Helpers ─────────────────────────────────────────────────────────────

def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated

def get_current_user():
    if 'user_id' not in session:
        return None
    row = get_db().execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    return row

@app.context_processor
def inject_user():
    return dict(current_user=get_current_user())

# ─── File Processing ──────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def normalize_columns(df):
    """Map varied column name styles onto our fixed schema keys."""
    col_map = {}
    for col in df.columns:
        lc = col.strip().lower().replace(' ', '_').replace('-', '_')
        if lc in ('order_id', 'orderid', 'order_number'):
            col_map[col] = 'order_id'
        elif lc in ('date', 'order_date', 'sale_date', 'transaction_date'):
            col_map[col] = 'date'
        elif lc in ('product', 'product_name', 'item', 'item_name', 'name'):
            col_map[col] = 'product'
        elif lc in ('category', 'product_category', 'type', 'segment'):
            col_map[col] = 'category'
        elif lc in ('quantity', 'qty', 'units', 'count'):
            col_map[col] = 'quantity'
        elif lc in ('unit_price', 'price', 'unit_cost', 'price_per_unit'):
            col_map[col] = 'unit_price'
        elif lc in ('total', 'revenue', 'total_revenue', 'sales', 'total_sales',
                    'total_amount', 'amount'):
            col_map[col] = 'total_revenue'
        elif lc in ('region', 'area', 'location', 'territory', 'zone'):
            col_map[col] = 'region'
        elif lc in ('customer', 'customer_name', 'client', 'buyer'):
            col_map[col] = 'customer'
    df.rename(columns=col_map, inplace=True)
    return df

def safe_float(val, default=0.0):
    try:
        return float(val) if pd.notna(val) else default
    except Exception:
        return default

def safe_int(val, default=1):
    try:
        return int(val) if pd.notna(val) else default
    except Exception:
        return default

def safe_str(val, default=''):
    try:
        return str(val) if pd.notna(val) else default
    except Exception:
        return default

def process_dataframe(df, batch_id):
    """Validate, clean, and bulk-insert rows into the sales table."""
    df = normalize_columns(df)
    errors = []
    rows = []

    required = ['date', 'product', 'category']
    missing = [c for c in required if c not in df.columns]
    if missing:
        return 0, [f"Missing required columns: {', '.join(missing)}. "
                   f"Found: {', '.join(df.columns.tolist())}"]

    for idx, row in df.iterrows():
        try:
            date_val = pd.to_datetime(row['date']).strftime('%Y-%m-%d')
            qty        = safe_int(row.get('quantity', 1))
            unit_price = safe_float(row.get('unit_price', 0))
            raw_total  = row.get('total_revenue', None)
            total      = safe_float(raw_total) if (raw_total is not None and pd.notna(raw_total)) \
                         else qty * unit_price
            if unit_price == 0 and total > 0 and qty > 0:
                unit_price = total / qty

            rows.append((
                safe_str(row.get('order_id', '')),
                date_val,
                safe_str(row['product']),
                safe_str(row['category']),
                qty,
                unit_price,
                total,
                safe_str(row.get('region', 'Unknown'), 'Unknown'),
                safe_str(row.get('customer', '')),
                batch_id,
            ))
        except Exception as e:
            errors.append(f"Row {idx + 2}: {e}")

    if rows:
        db = get_db()
        db.executemany(
            """INSERT INTO sales
               (order_id, date, product, category, quantity,
                unit_price, total_revenue, region, customer, upload_batch)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            rows
        )
        db.commit()

    return len(rows), errors

def build_where(start=None, end=None, category=None, product=None):
    """Return a (WHERE …, params) tuple for SQL filtering."""
    clauses, params = [], []
    if start:
        clauses.append("date >= ?"); params.append(start)
    if end:
        clauses.append("date <= ?"); params.append(end)
    if category and category != 'all':
        clauses.append("category = ?"); params.append(category)
    if product and product != 'all':
        clauses.append("product = ?"); params.append(product)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    return where, params

def parse_filter_args(args):
    return (
        args.get('start', ''),
        args.get('end', ''),
        args.get('category', 'all'),
        args.get('product', 'all'),
    )

# ─── Auth Routes ──────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('user_id'):
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = get_db().execute(
            "SELECT * FROM users WHERE username=?", (username,)
        ).fetchone()
        if user and user['password_hash'] == hash_password(password):
            session.clear()
            session['user_id']  = user['id']
            session['username'] = user['username']
            session.permanent   = bool(request.form.get('remember'))
            nxt = request.args.get('next') or url_for('dashboard')
            return redirect(nxt)
        flash('Invalid username or password.', 'error')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if session.get('user_id'):
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email    = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm  = request.form.get('confirm_password', '')
        db = get_db()
        if password != confirm:
            flash('Passwords do not match.', 'error')
        elif db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone():
            flash('Username already taken.', 'error')
        elif db.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone():
            flash('Email already registered.', 'error')
        else:
            cur = db.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (?,?,?)",
                (username, email, hash_password(password))
            )
            db.commit()
            session['user_id']  = cur.lastrowid
            session['username'] = username
            flash('Account created! Welcome.', 'success')
            return redirect(url_for('dashboard'))
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ─── Main Dashboard ───────────────────────────────────────────────────────────

@app.route('/')
@login_required
def dashboard():
    db = get_db()
    categories = [r[0] for r in
                  db.execute("SELECT DISTINCT category FROM sales ORDER BY category").fetchall()]
    has_data = db.execute("SELECT COUNT(*) FROM sales").fetchone()[0] > 0
    return render_template('dashboard.html', categories=categories, has_data=has_data)

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected.', 'error')
            return redirect(request.url)
        file = request.files['file']
        if not file or file.filename == '':
            flash('No file selected.', 'error')
            return redirect(request.url)
        if not allowed_file(file.filename):
            flash('Only CSV and Excel files (.csv, .xlsx, .xls) are allowed.', 'error')
            return redirect(request.url)

        filename  = secure_filename(file.filename)
        ext       = filename.rsplit('.', 1)[1].lower()
        batch_id  = datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S') + f"_{session['user_id']}"
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{batch_id}_{filename}")
        file.save(save_path)

        try:
            df = pd.read_csv(save_path) if ext == 'csv' else pd.read_excel(save_path)
            inserted, errors = process_dataframe(df, batch_id)
            if inserted:
                flash(f'✓ Successfully imported {inserted} records.', 'success')
            for e in errors[:5]:
                flash(f'⚠ {e}', 'warning')
        except Exception as e:
            flash(f'Error processing file: {e}', 'error')

        return redirect(url_for('dashboard'))

    return render_template('upload.html')

@app.route('/clear-data', methods=['POST'])
@login_required
def clear_data():
    db = get_db()
    db.execute("DELETE FROM sales")
    db.commit()
    flash('All data cleared successfully.', 'success')
    return redirect(url_for('dashboard'))

# ─── API — KPIs ───────────────────────────────────────────────────────────────

@app.route('/api/kpis')
@login_required
def api_kpis():
    start, end, cat, prod = parse_filter_args(request.args)
    where, params = build_where(start, end, cat, prod)
    db = get_db()
    r = db.execute(
        f"SELECT COALESCE(SUM(total_revenue),0), COUNT(*), COALESCE(SUM(quantity),0) FROM sales {where}",
        params
    ).fetchone()
    total_rev, total_orders, total_qty = r
    avg_order = total_rev / total_orders if total_orders else 0
    return jsonify({
        'total_revenue':   round(total_rev, 2),
        'total_sales':     total_orders,
        'total_quantity':  total_qty,
        'avg_order_value': round(avg_order, 2),
    })

# ─── API — Revenue Trend ──────────────────────────────────────────────────────

@app.route('/api/revenue-trend')
@login_required
def api_revenue_trend():
    start, end, cat, prod = parse_filter_args(request.args)
    where, params = build_where(start, end, cat, prod)
    db = get_db()
    rows = db.execute(
        f"""SELECT strftime('%Y', date) yr, strftime('%m', date) mo,
                   SUM(total_revenue) rev, COUNT(*) orders
            FROM sales {where}
            GROUP BY yr, mo ORDER BY yr, mo""",
        params
    ).fetchall()
    months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    return jsonify({
        'labels':  [f"{months[int(r['mo'])-1]} {r['yr']}" for r in rows],
        'revenue': [round(float(r['rev']), 2) for r in rows],
        'orders':  [int(r['orders']) for r in rows],
    })

# ─── API — Top Products ───────────────────────────────────────────────────────

@app.route('/api/top-products')
@login_required
def api_top_products():
    start, end, cat, _ = parse_filter_args(request.args)
    where, params = build_where(start, end, cat)
    limit = min(int(request.args.get('limit', 10)), 20)
    db = get_db()
    rows = db.execute(
        f"""SELECT product, SUM(total_revenue) rev, SUM(quantity) qty
            FROM sales {where}
            GROUP BY product ORDER BY rev DESC LIMIT ?""",
        params + [limit]
    ).fetchall()
    return jsonify({
        'labels':  [r['product'] for r in rows],
        'revenue': [round(float(r['rev']), 2) for r in rows],
        'qty':     [int(r['qty']) for r in rows],
    })

# ─── API — Category Distribution ─────────────────────────────────────────────

@app.route('/api/category-distribution')
@login_required
def api_category_distribution():
    start, end, _, _ = parse_filter_args(request.args)
    where, params = build_where(start, end)
    db = get_db()
    rows = db.execute(
        f"""SELECT category, SUM(total_revenue) rev
            FROM sales {where}
            GROUP BY category ORDER BY rev DESC""",
        params
    ).fetchall()
    return jsonify({
        'labels': [r['category'] for r in rows],
        'values': [round(float(r['rev']), 2) for r in rows],
    })

# ─── API — Region Breakdown ───────────────────────────────────────────────────

@app.route('/api/region-breakdown')
@login_required
def api_region_breakdown():
    start, end, cat, _ = parse_filter_args(request.args)
    where, params = build_where(start, end, cat)
    db = get_db()
    rows = db.execute(
        f"""SELECT region, SUM(total_revenue) rev, COUNT(*) orders
            FROM sales {where}
            GROUP BY region ORDER BY rev DESC""",
        params
    ).fetchall()
    return jsonify({
        'labels':  [r['region'] for r in rows],
        'revenue': [round(float(r['rev']), 2) for r in rows],
        'orders':  [int(r['orders']) for r in rows],
    })

# ─── API — Filter Options ─────────────────────────────────────────────────────

@app.route('/api/filters')
@login_required
def api_filters():
    db  = get_db()
    cat = request.args.get('category', 'all')
    if cat != 'all':
        prods = [r[0] for r in db.execute(
            "SELECT DISTINCT product FROM sales WHERE category=? ORDER BY product", (cat,)
        ).fetchall()]
    else:
        prods = [r[0] for r in db.execute(
            "SELECT DISTINCT product FROM sales ORDER BY product"
        ).fetchall()]
    cats = [r[0] for r in db.execute(
        "SELECT DISTINCT category FROM sales ORDER BY category"
    ).fetchall()]
    return jsonify({'categories': cats, 'products': prods})

# ─── API — Recent Sales ───────────────────────────────────────────────────────

@app.route('/api/recent-sales')
@login_required
def api_recent_sales():
    rows = get_db().execute(
        "SELECT * FROM sales ORDER BY date DESC, id DESC LIMIT 20"
    ).fetchall()
    return jsonify([dict(r) for r in rows])

# ─── Export — PDF ─────────────────────────────────────────────────────────────

@app.route('/export/pdf')
@login_required
def export_pdf():
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.units import cm

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2*cm, rightMargin=2*cm)
        styles = getSampleStyleSheet()
        elems  = []

        # Title
        title_s = ParagraphStyle('T', fontSize=22, spaceAfter=6,
                                 textColor=colors.HexColor('#1a1a2e'),
                                 fontName='Helvetica-Bold')
        elems.append(Paragraph("Sales & Revenue Analysis Report", title_s))
        elems.append(Paragraph(
            f"Generated: {datetime.datetime.now().strftime('%B %d, %Y %H:%M')}",
            styles['Normal']
        ))
        elems.append(Spacer(1, 0.5*cm))

        db = get_db()
        r  = db.execute(
            "SELECT COALESCE(SUM(total_revenue),0), COUNT(*), COALESCE(SUM(quantity),0) FROM sales"
        ).fetchone()
        total_rev, total_orders, total_qty = r
        avg_order = total_rev / total_orders if total_orders else 0

        kpi_data = [
            ['Metric', 'Value'],
            ['Total Revenue',    f"${total_rev:,.2f}"],
            ['Total Orders',     f"{total_orders:,}"],
            ['Total Units Sold', f"{total_qty:,}"],
            ['Avg Order Value',  f"${avg_order:,.2f}"],
        ]
        kpi_table = Table(kpi_data, colWidths=[8*cm, 8*cm])
        kpi_table.setStyle(TableStyle([
            ('BACKGROUND',    (0,0),(-1,0), colors.HexColor('#1a1a2e')),
            ('TEXTCOLOR',     (0,0),(-1,0), colors.white),
            ('FONTNAME',      (0,0),(-1,0), 'Helvetica-Bold'),
            ('FONTSIZE',      (0,0),(-1,-1), 11),
            ('ROWBACKGROUNDS',(0,1),(-1,-1), [colors.white, colors.HexColor('#f0f4f8')]),
            ('GRID',          (0,0),(-1,-1), 0.5, colors.HexColor('#cccccc')),
            ('ALIGN',         (1,0),(1,-1),  'RIGHT'),
            ('PADDING',       (0,0),(-1,-1), 8),
        ]))
        elems.append(kpi_table)
        elems.append(Spacer(1, 0.5*cm))

        # Top products
        top = db.execute(
            "SELECT product, SUM(total_revenue) rev FROM sales GROUP BY product ORDER BY rev DESC LIMIT 10"
        ).fetchall()
        if top:
            elems.append(Paragraph("Top 10 Products by Revenue", styles['Heading2']))
            prod_data = [['Product', 'Revenue']] + [[r['product'], f"${float(r['rev']):,.2f}"] for r in top]
            prod_table = Table(prod_data, colWidths=[12*cm, 5*cm])
            prod_table.setStyle(TableStyle([
                ('BACKGROUND',    (0,0),(-1,0), colors.HexColor('#4361ee')),
                ('TEXTCOLOR',     (0,0),(-1,0), colors.white),
                ('FONTNAME',      (0,0),(-1,0), 'Helvetica-Bold'),
                ('ROWBACKGROUNDS',(0,1),(-1,-1), [colors.white, colors.HexColor('#f0f4f8')]),
                ('GRID',          (0,0),(-1,-1), 0.5, colors.HexColor('#cccccc')),
                ('ALIGN',         (1,0),(1,-1),  'RIGHT'),
                ('PADDING',       (0,0),(-1,-1), 7),
                ('FONTSIZE',      (0,0),(-1,-1), 10),
            ]))
            elems.append(prod_table)

        doc.build(elems)
        buf.seek(0)
        fname = f"sales_report_{datetime.datetime.now().strftime('%Y%m%d')}.pdf"
        return send_file(buf, mimetype='application/pdf', as_attachment=True,
                         download_name=fname)

    except ImportError:
        flash('ReportLab is required for PDF export. Run: pip install reportlab', 'error')
        return redirect(url_for('dashboard'))

# ─── Seed Demo Data ───────────────────────────────────────────────────────────

def seed_demo():
    """Populate DB with 500 realistic demo records on first launch."""
    db = sqlite3.connect(DB_PATH)
    if db.execute("SELECT COUNT(*) FROM sales").fetchone()[0] > 0:
        db.close()
        return

    products = {
        'Electronics':   ['Laptop Pro 15"','Wireless Headphones','4K Monitor','USB-C Hub','Mechanical Keyboard'],
        'Clothing':      ['Running Shoes','Winter Jacket','Yoga Pants','Cotton T-Shirt','Denim Jeans'],
        'Books':         ['Python Mastery','Data Science Guide','Clean Code','Design Patterns','The Lean Startup'],
        'Home & Garden': ['Coffee Maker','Air Purifier','LED Desk Lamp','Bamboo Organizer','Smart Thermostat'],
        'Sports':        ['Yoga Mat','Resistance Bands','Water Bottle','Running Watch','Jump Rope'],
    }
    prices = {
        'Laptop Pro 15"':1299,'Wireless Headphones':249,'4K Monitor':599,
        'USB-C Hub':79,'Mechanical Keyboard':149,'Running Shoes':129,
        'Winter Jacket':199,'Yoga Pants':69,'Cotton T-Shirt':29,'Denim Jeans':89,
        'Python Mastery':49,'Data Science Guide':59,'Clean Code':39,
        'Design Patterns':44,'The Lean Startup':34,'Coffee Maker':189,
        'Air Purifier':299,'LED Desk Lamp':59,'Bamboo Organizer':39,
        'Smart Thermostat':249,'Yoga Mat':49,'Resistance Bands':29,
        'Water Bottle':39,'Running Watch':299,'Jump Rope':19,
    }
    regions  = ['North','South','East','West','Central']
    start_dt = datetime.date(2023, 1, 1)
    rows = []

    random.seed(42)
    for i in range(500):
        sale_date = (start_dt + datetime.timedelta(days=random.randint(0, 730))).isoformat()
        cat   = random.choice(list(products))
        prod  = random.choice(products[cat])
        price = prices[prod]
        qty   = random.randint(1, 5)
        rows.append((
            f"ORD-{10000+i}", sale_date, prod, cat, qty,
            float(price), round(price * qty, 2),
            random.choice(regions),
            f"Customer {random.randint(1, 200)}",
            'demo_seed',
        ))

    db.executemany(
        """INSERT INTO sales (order_id,date,product,category,quantity,
           unit_price,total_revenue,region,customer,upload_batch)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        rows
    )
    db.commit()
    db.close()
    print("✓ Seeded 500 demo records.")

# ─── Application Bootstrap ────────────────────────────────────────────────────

# Initialise DB schema
init_db()

# Create demo user if absent
_db = sqlite3.connect(DB_PATH)
if not _db.execute("SELECT id FROM users WHERE username='demo'").fetchone():
    _db.execute(
        "INSERT INTO users (username, email, password_hash) VALUES (?,?,?)",
        ('demo', 'demo@example.com', hash_password('demo1234'))
    )
    _db.commit()
    print("✓ Demo user created  →  username: demo  /  password: demo1234")
_db.close()

seed_demo()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
