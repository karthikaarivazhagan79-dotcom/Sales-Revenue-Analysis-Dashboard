/**
 * dashboard.js
 * ──────────────────────────────────────────────────────────────
 * Handles all dashboard interactivity:
 *  - Chart initialization & rendering (Chart.js)
 *  - KPI card updates
 *  - Filter bar interactions
 *  - Recent transactions table
 *  - Dynamic product filter population
 */

'use strict';

// ─── Chart Registry ────────────────────────────────────────────────────────

const charts = {};

// ─── Color Palette (synced with CSS variables) ─────────────────────────────

const PALETTE = [
  '#4361ee', '#7209b7', '#06d6a0',
  '#ffd166', '#ef476f', '#4cc9f0',
  '#f72585', '#3a0ca3', '#480ca8', '#560bad',
];

function getCSSVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function chartDefaults() {
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  return {
    gridColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)',
    tickColor: isDark ? '#555570' : '#9090b0',
    tooltipBg: isDark ? '#1a1a2e' : '#ffffff',
    tooltipBorder: isDark ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
    tooltipText: isDark ? '#f0f0ff' : '#0d0d1e',
  };
}

// ─── Filter State ──────────────────────────────────────────────────────────

function getFilters() {
  return {
    start: document.getElementById('startDate')?.value || '',
    end:   document.getElementById('endDate')?.value || '',
    category: document.getElementById('categoryFilter')?.value || 'all',
    product:  document.getElementById('productFilter')?.value || 'all',
  };
}

function filterParams() {
  const f = getFilters();
  const p = new URLSearchParams();
  if (f.start)    p.set('start', f.start);
  if (f.end)      p.set('end', f.end);
  if (f.category !== 'all') p.set('category', f.category);
  if (f.product  !== 'all') p.set('product',  f.product);
  return p.toString();
}

// ─── Fetch Helpers ─────────────────────────────────────────────────────────

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// ─── KPI Cards ─────────────────────────────────────────────────────────────

async function loadKPIs() {
  try {
    const data = await fetchJSON(`/api/kpis?${filterParams()}`);
    animateNumber('kpiRevenue', data.total_revenue, v => '$' + formatNum(v));
    animateNumber('kpiOrders',  data.total_sales,   v => formatNum(v, 0));
    animateNumber('kpiUnits',   data.total_quantity, v => formatNum(v, 0));
    animateNumber('kpiAvg',     data.avg_order_value, v => '$' + formatNum(v));
  } catch (e) {
    console.error('KPI load error:', e);
  }
}

function animateNumber(id, target, formatter) {
  const el = document.getElementById(id);
  if (!el) return;
  const start = 0;
  const duration = 800;
  const startTime = performance.now();
  function step(now) {
    const progress = Math.min((now - startTime) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = formatter(start + (target - start) * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function formatNum(v, decimals = 2) {
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(1) + 'M';
  if (v >= 1_000)     return (v / 1_000).toFixed(1) + 'K';
  return Number(v).toFixed(decimals);
}

// ─── Revenue Trend Chart ───────────────────────────────────────────────────

async function loadRevenueTrend() {
  const data = await fetchJSON(`/api/revenue-trend?${filterParams()}`);
  const ctx = document.getElementById('revenueTrendChart');
  if (!ctx) return;

  const d = chartDefaults();

  if (charts.trend) charts.trend.destroy();
  charts.trend = new Chart(ctx, {
    type: 'line',
    data: {
      labels: data.labels,
      datasets: [
        {
          label: 'Revenue ($)',
          data: data.revenue,
          borderColor: PALETTE[0],
          backgroundColor: `${PALETTE[0]}22`,
          borderWidth: 2.5,
          pointRadius: 4,
          pointHoverRadius: 6,
          fill: true,
          tension: 0.4,
          yAxisID: 'y',
        },
        {
          label: 'Orders',
          data: data.orders,
          borderColor: PALETTE[1],
          backgroundColor: 'transparent',
          borderWidth: 2,
          borderDash: [5, 4],
          pointRadius: 3,
          pointHoverRadius: 5,
          fill: false,
          tension: 0.4,
          yAxisID: 'y1',
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: d.tooltipBg,
          borderColor: d.tooltipBorder,
          borderWidth: 1,
          titleColor: d.tooltipText,
          bodyColor: d.tooltipText,
          padding: 12,
          callbacks: {
            label: ctx => ctx.datasetIndex === 0
              ? ` $${ctx.parsed.y.toLocaleString()}`
              : ` ${ctx.parsed.y} orders`,
          },
        },
      },
      scales: {
        x: {
          grid: { color: d.gridColor },
          ticks: { color: d.tickColor, font: { family: 'DM Sans', size: 11 } },
        },
        y: {
          grid: { color: d.gridColor },
          ticks: {
            color: d.tickColor,
            font: { family: 'DM Sans', size: 11 },
            callback: v => '$' + formatNum(v),
          },
          position: 'left',
        },
        y1: {
          grid: { drawOnChartArea: false },
          ticks: { color: d.tickColor, font: { family: 'DM Sans', size: 11 } },
          position: 'right',
        },
      },
    },
  });
}

// ─── Top Products Chart ────────────────────────────────────────────────────

async function loadTopProducts() {
  const data = await fetchJSON(`/api/top-products?${filterParams()}`);
  const ctx = document.getElementById('topProductsChart');
  if (!ctx) return;

  const d = chartDefaults();

  if (charts.products) charts.products.destroy();
  charts.products = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.labels,
      datasets: [{
        label: 'Revenue ($)',
        data: data.revenue,
        backgroundColor: PALETTE.map(c => c + 'cc'),
        borderColor: PALETTE,
        borderWidth: 1,
        borderRadius: 6,
        borderSkipped: false,
      }],
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: d.tooltipBg,
          borderColor: d.tooltipBorder,
          borderWidth: 1,
          titleColor: d.tooltipText,
          bodyColor: d.tooltipText,
          padding: 12,
          callbacks: {
            label: ctx => ` $${ctx.parsed.x.toLocaleString()}`,
          },
        },
      },
      scales: {
        x: {
          grid: { color: d.gridColor },
          ticks: {
            color: d.tickColor,
            font: { family: 'DM Sans', size: 11 },
            callback: v => '$' + formatNum(v),
          },
        },
        y: {
          grid: { display: false },
          ticks: {
            color: d.tickColor,
            font: { family: 'DM Sans', size: 11 },
            callback: v => v.length > 18 ? v.slice(0, 18) + '…' : v,
          },
        },
      },
    },
  });
}

// ─── Category Pie Chart ────────────────────────────────────────────────────

async function loadCategoryChart() {
  const data = await fetchJSON(`/api/category-distribution?${filterParams()}`);
  const ctx = document.getElementById('categoryChart');
  if (!ctx) return;

  const d = chartDefaults();
  if (charts.category) charts.category.destroy();

  charts.category = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: data.labels,
      datasets: [{
        data: data.values,
        backgroundColor: PALETTE.map(c => c + 'cc'),
        borderColor: PALETTE,
        borderWidth: 2,
        hoverOffset: 8,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '60%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: d.tickColor,
            font: { family: 'DM Sans', size: 11 },
            padding: 12,
            boxWidth: 10, boxHeight: 10,
          },
        },
        tooltip: {
          backgroundColor: d.tooltipBg,
          borderColor: d.tooltipBorder,
          borderWidth: 1,
          titleColor: d.tooltipText,
          bodyColor: d.tooltipText,
          padding: 12,
          callbacks: {
            label: ctx => ` $${ctx.parsed.toLocaleString()}`,
          },
        },
      },
    },
  });
}

// ─── Region Chart ──────────────────────────────────────────────────────────

async function loadRegionChart() {
  const data = await fetchJSON(`/api/region-breakdown?${filterParams()}`);
  const ctx = document.getElementById('regionChart');
  if (!ctx) return;

  const d = chartDefaults();
  if (charts.region) charts.region.destroy();

  charts.region = new Chart(ctx, {
    type: 'polarArea',
    data: {
      labels: data.labels,
      datasets: [{
        data: data.revenue,
        backgroundColor: PALETTE.map(c => c + '99'),
        borderColor: PALETTE,
        borderWidth: 1.5,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: d.tickColor,
            font: { family: 'DM Sans', size: 11 },
            padding: 12,
            boxWidth: 10, boxHeight: 10,
          },
        },
        tooltip: {
          backgroundColor: d.tooltipBg,
          borderColor: d.tooltipBorder,
          borderWidth: 1,
          titleColor: d.tooltipText,
          bodyColor: d.tooltipText,
          padding: 12,
          callbacks: {
            label: ctx => ` $${ctx.parsed.r.toLocaleString()}`,
          },
        },
      },
      scales: {
        r: {
          grid: { color: d.gridColor },
          ticks: { display: false },
        },
      },
    },
  });
}

// ─── Recent Sales Table ────────────────────────────────────────────────────

async function loadRecentSales() {
  const tbody = document.getElementById('recentTableBody');
  if (!tbody) return;
  try {
    const data = await fetchJSON('/api/recent-sales');
    if (!data.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="table-loading">No records found</td></tr>';
      return;
    }
    tbody.innerHTML = data.map(s => `
      <tr>
        <td><code style="font-size:11px;font-family:var(--font-mono, monospace)">${s.order_id || '—'}</code></td>
        <td>${s.date}</td>
        <td>${truncate(s.product, 24)}</td>
        <td><span style="padding:2px 8px;border-radius:20px;font-size:11px;background:rgba(67,97,238,0.15);color:#4361ee">${s.category}</span></td>
        <td>${s.quantity}</td>
        <td>$${Number(s.unit_price).toFixed(2)}</td>
        <td><strong>$${Number(s.total_revenue).toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2})}</strong></td>
        <td>${s.region || '—'}</td>
      </tr>
    `).join('');
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="8" class="table-loading">Error loading data</td></tr>`;
  }
}

function truncate(str, len) {
  return str && str.length > len ? str.slice(0, len) + '…' : str;
}

// ─── Product Filter Loader ─────────────────────────────────────────────────

async function loadProductFilter(selectedCategory) {
  const sel = document.getElementById('productFilter');
  if (!sel) return;
  const params = selectedCategory && selectedCategory !== 'all' ? `?category=${selectedCategory}` : '';
  try {
    const data = await fetchJSON(`/api/filters${params}`);
    const currentVal = sel.value;
    sel.innerHTML = '<option value="all">All Products</option>';
    data.products.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p;
      if (p === currentVal) opt.selected = true;
      sel.appendChild(opt);
    });
  } catch (e) { /* silent */ }
}

// ─── Refresh All ───────────────────────────────────────────────────────────

function refreshAll() {
  loadKPIs();
  loadRevenueTrend();
  loadTopProducts();
  loadCategoryChart();
  loadRegionChart();
  loadRecentSales();
}

// ─── Init ──────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  // Bind filter events
  const applyBtn = document.getElementById('applyFilters');
  const resetBtn = document.getElementById('resetFilters');
  const catFilter = document.getElementById('categoryFilter');

  if (applyBtn) applyBtn.addEventListener('click', refreshAll);

  if (resetBtn) resetBtn.addEventListener('click', () => {
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.getElementById('categoryFilter').value = 'all';
    document.getElementById('productFilter').value = 'all';
    refreshAll();
  });

  if (catFilter) {
    catFilter.addEventListener('change', () => {
      loadProductFilter(catFilter.value);
    });
  }

  // Reload charts on theme toggle so colors match
  const themeBtn = document.getElementById('themeToggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      setTimeout(refreshAll, 350); // wait for CSS transition
    });
  }

  // Initial load
  loadProductFilter();
  refreshAll();
});
